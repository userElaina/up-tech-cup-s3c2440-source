/* $RCSfile: INTERN.h,v $$Revision: 1.1.1.1 $$Date: 2001/05/02 15:40:20 $
 *
 *    Copyright (c) 1991-1997, Larry Wall
 *
 *    You may distribute under the terms of either the GNU General Public
 *    License or the Artistic License, as specified in the README file.
 *
 * $Log: INTERN.h,v $
 * Revision 1.1.1.1  2001/05/02 15:40:20  dcleland
 * Activestate Perl
 *
 */

#undef EXT
#define EXT

#undef INIT
#define INIT(x) = x

#define DOINIT

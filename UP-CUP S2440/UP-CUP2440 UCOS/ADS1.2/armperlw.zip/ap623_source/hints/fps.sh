ccflags="$ccflags -J"
